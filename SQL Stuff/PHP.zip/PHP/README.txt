1) Download php_apcu.dll from <https://pecl.php.net/package/APCu/5.1.8/windows> (choose proper PHP version, architecture and thread safety mode)

2) Download php_apcu_bc.dll from <https://pecl.php.net/package/apcu_bc/1.0.3/windows> (for Uniform Server Zero, use thread safe x86 windows dll)

3) Save both files in ext dir under your PHP installation folder

4) Load extensions in php.ini: (for Uniform Server Zero, just put the extensions in "extensions" folder, and then enable via control panel)
extension=php_apcu.dll
extension=php_apcu_bc.dll

5) Configure APCu in php.ini
[APCu]
apc.enabled=1
apc.shm_size=32M
apc.ttl=7200
apc.enable_cli=1
apc.serializer=php